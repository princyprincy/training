README

# Day 1
	* Database Basics and Schema
	* Managing Database and Tables (DDL)
# Day 2
# Day 3
# Day 4
# Day 5