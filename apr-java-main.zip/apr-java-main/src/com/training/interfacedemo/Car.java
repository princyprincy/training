package com.training.interfacedemo;

public interface Car {

	// method - public abstract
	void start();

	void drive();
}
