package com.training.interfacedemo;

public class CarTest {
	
	public static void main(String[] args) {
		//Car car = new Car();
		Car car = new SportsCar();
		car.start();
		car.drive();
	}

}
