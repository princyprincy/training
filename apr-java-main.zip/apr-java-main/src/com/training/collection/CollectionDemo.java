package com.training.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import com.training.methods.Car;

public class CollectionDemo {
	public static void main(String[] args) {
//		ArrayList numbers = new ArrayList<>();
//		numbers.add("Arun");
//		numbers.add(12);
//		numbers.add(false);
//		for(Object t : numbers) {
//			
//		}
//		System.out.println(numbers);

		// creating array list of strings
//		ArrayList<String> list = new ArrayList<>();
//		// adding elements to the list
//		list.add("Arun");
//		list.add("Sumitha");
//		list.add("Vignesh");
//		list.add("Sumitha");
//		// printing the entire list 
//		System.out.println(list);
//		System.out.println("Printing name starts with s");
//		for(String name:list) {
//			if(name.startsWith("S") || name.startsWith("s")) {
//				System.out.println(name);
//			}
//		}
//		list.get(3);

//		ArrayList<Car> carList = new ArrayList<>();
//		carList.add(new Car("FORD", 123));
//		carList.add(new Car("AUDI", 234));
//		carList.add(new Car("BMW", 345));
//		System.out.println(carList);
//		for (Car car : carList) {
//			String name = car.getModel();
//			if (name.equalsIgnoreCase("audi")) {
//				System.out.println("Found Audi");
//			}
//		}
//
//		HashSet<String> set = new HashSet<>();
//		set.add("Arun");
//		set.add("Sumitha");
//		set.add("Vignesh");
//		set.add("Arun");
//		set.add("Vignesh");
//		System.out.println(set);
//

		// creating a map
//		HashMap<String, String> map = new HashMap<>();
//		// putting <key,value> to map
//		map.put("Arun", "Anthoni");
//		map.put("Sumitha", "Velmani");
//		map.put("Vignesh", "R");
//		// printing the entire map
//		System.out.println(map);
//		for (Map.Entry<String, String> name : map.entrySet()) {
//			if (name.getKey().equals("Vignesh")) {
//				System.out.println(name.getKey());
//				System.out.println(name.getValue());
//			}
//		}

	}
}
