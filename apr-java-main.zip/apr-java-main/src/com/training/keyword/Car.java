package com.training.keyword;

public class Car {
	private int speed;// instance variable
	public int getSpeed(){
		return speed;
	}
	public void setSpeed(int speed) {//param/arg/local
		this.speed = speed;
	}

}
