package com.training.package1;

public class Test3 {
	public static void main(String[] args) {
		System.out.println(Test1.publicVar);
		System.out.println(Test1.protectedVar);
		System.out.println(Test1.defaultVar);
//		System.out.println(Test1.privateVar);
	}
}
