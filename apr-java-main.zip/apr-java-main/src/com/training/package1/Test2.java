package com.training.package1;

public class Test2 extends Test1 {
	public static void main(String[] args) {
		System.out.println(publicVar);
		System.out.println(protectedVar);
		System.out.println(defaultVar);
//		System.out.println(privateVar);
	}
}
