package com.training.exception;

public class CarNameNotFoundException extends Exception {

	public CarNameNotFoundException() {
		System.out.println("Invalid Car Name");
	}
}
