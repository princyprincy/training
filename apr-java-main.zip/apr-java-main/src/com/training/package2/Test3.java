package com.training.package2;

import com.training.package1.Test1;

public class Test3 {
	public static void main(String[] args) {
		System.out.println(Test1.publicVar);
	//	System.out.println(Test1.protectedVar);
	//	System.out.println(Test1.defaultVar);
	//	System.out.println(Test1.privateVar);
	}
}
