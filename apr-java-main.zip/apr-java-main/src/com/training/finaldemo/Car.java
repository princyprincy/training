package com.training.finaldemo;

public class Car {
	
	static final int NUMBER_OF_WHEELS = 4;
	final void drive() {
		
	}
	void drive(String model) {
		
	}
	

}

class Taxi extends Car{
//	void drive() {
//		
//	}
	
}
